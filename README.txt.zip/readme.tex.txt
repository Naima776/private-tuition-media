Private Tuition Media Website Package
---------------------------------------
এই প্যাকেজে রয়েছে:
1. index.html - হোম পেজ
2. login.html - লগইন / সাইনআপ পেজ (Gmail লগইন UI)
3. style.css - সাইটের স্টাইলিং
4. script.js - JavaScript ফাংশনালিটি
5. images/ - প্রয়োজনীয় ইমেজ ফাইল

ব্যবহার:
- ফোল্ডারটি আনজিপ করুন।
- index.html-এ ডাবল ক্লিক করে ব্রাউজারে ওয়েবসাইটটি দেখুন।
- সরাসরি কোড এডিট করে নিজের প্রয়োজন অনুযায়ী পরিবর্তন করুন।

© 2025 Private Tuition Media